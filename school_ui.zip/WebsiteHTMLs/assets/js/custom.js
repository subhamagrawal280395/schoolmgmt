$(document).ready(function() {
    // Owl-carousel //
    $('#owl-carousel1').owlCarousel({
        loop: false,
        autoWidth: false,
        margin: 30,
        dots: false,
        nav: true,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            767: {
                items: 2
            }
        }
    });

    // News Owl //
    $('#owlCarousel2').owlCarousel({
        loop: false,
        autoWidth: false,
        margin: 10,
        dots: false,
        nav: true,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsiveClass: true,
        responsive: {
            0: {
                items: 1
            },
            768: {
                items: 2
            },
            992: {
                items: 3
            }
        }
    });

    // Responsive Menu  //
    $('.js-navbar-toggler').click(function() {
        $('.navbar-md-collapse').addClass('active');
        $('.overlay').addClass('active');
    });
    $('.overlay, .js-closeMenu').click(function() {
        $('.navbar-md-collapse').removeClass('active');
        $('.overlay').removeClass('active');
    });

    // menu scroll target //
    $('.js-scroll-trigger').click(function() {
        var target = $(this.hash);
        $('html, body').animate({
            scrollTop: (target.offset().top - 80)
        }, 1000);


        $('.navbar-md-collapse').removeClass('active');
        $('.overlay').removeClass('active');
    });

    $('.js-activemenu li a').click(function() {
        $('li').removeClass('active');
        $(this).parents('li').addClass('active');
    });

    // read more //
    $('.js-showdetails').on('shown.bs.collapse hidden.bs.collapse', function() {
        var $href = $(this).attr('id')
        var $this = $('a[href="#' + $href + '"]');
        if ($this.attr('aria-expanded') == 'true') {
            $this.html('Less <span class="icon-arrow icon--ml"></span>');
        } else {
            $this.html('Read More <span class="icon-arrow icon--ml"></span>');
        }
    });
});

// Scroll //
$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll > 50) {
        $("#navbar-scroll").addClass("gradient-blue");
    } else {
        $("#navbar-scroll").removeClass("gradient-blue");
    }
});


$(window).bind("load scroll", function() {});

//============= For email =============//
function sendMail() {
    // body...
    // $('trailform').submit(function(e){
    //e.preventDefault();
    var name = $('#name').val();
    var email = $('#email').val();
    var message = $('#message').val();
    var data = {
        "to": [email],
        "template": "mdsContactUs",
        "params": {
            "name": name,
            "email": email,
            "message": message,
            "phone":'',
            "organisation":''

        }
    };
    if (name != '' && email != '' && message != '') {

        $.ajax({
            url: 'http://mailapi.metadesignsolutions.com/mds-api/web/api/send-email',
            type: 'POST',
            dataType: 'JSON',
            data: data,
            success: function(response) {
                if (response.status == 1) {
                    $('.thankyou').text(response.message);
                    $('.thankyou').show();
                    setTimeout(function() {
                        $('.thankyou').hide();
                    }, 4000);
                    $('#name').val('');
                    $('#email').val('');
                    $('#message').val('');
                    console.log(response);
                }
            },
            error: function(err) {
                console.log(err.error);
            }
        });
    }
    // });
}