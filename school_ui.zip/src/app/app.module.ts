import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { routing } from './app.routing';
import { HttpClientService } from './http-client';
import { HttpClientModule,HttpClient } from '@angular/common/http';
import { SidebarComponent } from './components/shared/sidebar/sidebar.component';
import { NavbarComponent } from './components/shared/navbar/navbar.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import * as $ from 'jquery';
import { StudentService } from './services/student/student.service';
import { FileDropModule } from 'ngx-file-drop';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';
import { CalendarModule } from 'angular-calendar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SectionComponent } from './components/section/section.component';
import { DatePickerComponent } from './components/table-components/date-picker/date-picker.component';
import { DateFormattorComponent } from './components/table-components/date-formattor/date-formattor.component';
import { MarksComponent } from './components/marks/marks.component';
import { AttendenceComponent } from './components/attendence/attendence.component';
import { SelectDropDownModule } from 'ngx-select-dropdown'
export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    SectionComponent,
    DatePickerComponent,
    DateFormattorComponent,
    MarksComponent,
    AttendenceComponent,

    
  ],
  entryComponents:[
    DatePickerComponent,
    DateFormattorComponent
  ],
  imports: [
    SelectDropDownModule,
    NgxChartsModule,
    BrowserModule,
    routing,
    FormsModule,
    HttpClientModule,
    AngularMultiSelectModule,
    FileDropModule,
    AngularDateTimePickerModule,
    Ng2SmartTableModule,
    BrowserAnimationsModule,
    NgbModule.forRoot(),
    CalendarModule.forRoot(),
    TranslateModule.forRoot({
      loader: {
          provide: TranslateLoader,
          useFactory: (createTranslateLoader),
          deps: [HttpClient]
        }
  }),
  ],
  providers: [HttpClientService,StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
