import swal from 'sweetalert2';



// Confirm & Cancel Button
export function confirmCancelButton():Promise<any> {
    return swal({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#0CC27E',
        cancelButtonColor: '#FF586B',
        confirmButtonText: 'Yes, send it!',
        cancelButtonText: 'No, cancel!',
        confirmButtonClass: 'btn btn-success btn-raised mr-5',
        cancelButtonClass: 'btn btn-danger btn-raised',
        buttonsStyling: false
    })
}

// Success Type Alert
export function typeSuccess(short,long) {
    swal(short, long, "success");
}
// Cancel Type Alert
export function typeCancel(msg) {
    swal("Cancelled", msg , "error");
}