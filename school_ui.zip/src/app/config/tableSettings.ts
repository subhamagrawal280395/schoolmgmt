import { DateFormattorComponent } from "../components/table-components/date-formattor/date-formattor.component";
import { DatePickerComponent } from "../components/table-components/date-picker/date-picker.component";


// Smart DataTable
export const student = {
    actions: {
        position: 'right',
        width: '100px',
    },
    delete: {
        confirmDelete: true,
        deleteButtonContent: '<i class="icon-trash danger font-medium-3 mr-2"></i>'
    },
    add: {
        confirmCreate: true,
        createButtonContent: '<i class="icon-check success font-medium-3 mr-2"></i>',
        cancelButtonContent: '<i class="icon-close danger font-medium-3 mr-2"></i>',
        addButtonContent: '<i class="icon-plus success"></i>',
    },
    edit: {
        confirmSave: true,
        saveButtonContent: '<i class="icon-check success font-medium-3 mr-2"></i>',
        editButtonContent: '<i class="icon-pencil blue-grey font-medium-3 mr-2"></i>',
        cancelButtonContent: '<i class="icon-close danger font-medium-3 mr-2"></i>',
        attr: {
            class: "table table-bordered tableSmart--custom"
        }
    },
    columns: {
        name: {
            title: 'Full Name',
            filter: false,
            width: '20%',
        },
        birthDate: {
            title: 'Birthdate',
            filter: false,
            width: '20%',
            type:"custom",
            renderComponent:DateFormattorComponent,
            editor:{
                type: 'custom',
                component:DatePickerComponent
            }
        }
    },
    pager: {
        display: false,
        perPage: 10
    },
    attr: {
        class: "table table-bordered tableSmart--custom"
    }
};

export const marks = {
    actions: {
        position: 'right',
        width: '100px',
    },
    delete: {
        confirmDelete: true,
        deleteButtonContent: '<i class="icon-trash danger font-medium-3 mr-2"></i>'
    },
    add: {
        confirmCreate: true,
        createButtonContent: '<i class="icon-check success font-medium-3 mr-2"></i>',
        cancelButtonContent: '<i class="icon-close danger font-medium-3 mr-2"></i>',
        addButtonContent: '<i class="icon-plus success"></i>',
    },
    edit: {
        confirmSave: true,
        saveButtonContent: '<i class="icon-check success font-medium-3 mr-2"></i>',
        editButtonContent: '<i class="icon-pencil blue-grey font-medium-3 mr-2"></i>',
        cancelButtonContent: '<i class="icon-close danger font-medium-3 mr-2"></i>',
        attr: {
            class: "table table-bordered tableSmart--custom"
        }
    },
    columns: {
        examName: {
            title: 'Exam Name',
            filter: false,
            width: '20%',
            editable:false,
            editor:{
                type:'list',
                config: {
                    list: [{ value: "1", title: "1" }, { value: "2", title: "2" },{ value: "3", title: "3" }]
                }
            }
        },
        subject: {
            title: 'Subject',
            filter: false,
            width: '20%',
            editable:false
        },
        gained: {
            title: 'Gained',
            filter: false,
            width: '20%',
        },
        total: {
            title: 'Total',
            filter: false,
            width: '20%',
        }
    },
    pager: {
        display: false,
        perPage: 10
    },
    attr: {
        class: "table table-bordered tableSmart--custom"
    }
};