export var config = {

    apiBaseUrl:'http://localhost:8080/api/v1/'
}