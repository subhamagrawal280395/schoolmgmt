export class StudentModel{
    name:string;
    _id:string;
    birthDate:string;
    className:string;
    sectionName:string;
    isPresent:boolean=false;
    marks:MarksModel[]=new Array<MarksModel>();
}

export class MarksModel{
    year:number;
    examName:string
    subject:string
    gained:number
    total:number
}