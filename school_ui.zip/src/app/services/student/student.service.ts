import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { HttpClientService } from '../../http-client';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { config } from '../../config/env';
import {StudentModel,MarksModel} from '../../models/student.model';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {typeCancel} from '../../config/sweet-alerts';

@Injectable()
export class StudentService {
  private basePath:string='students';
  public studentsSettings:any={};
  constructor(private http: HttpClientService,private router : Router) {

  };


  getSettings() : Observable<any> {
    return this.http.get(`${this.basePath}/settings`)
    .catch(err=>this.handleError(err))
  }
  addStudent(data:StudentModel): Observable<any> {
    return this.http.post(`${this.basePath}`,data)
    .catch(err=>this.handleError(err))
  }
  updateStudent(id:string,data:StudentModel): Observable<any> {
    return this.http.put(`${this.basePath}/${id}`,data)
    .catch(err=>this.handleError(err))
  }
  deleteStudent(id:string): Observable<any> {
    return this.http.delete(`${this.basePath}/${id}`)
    .catch(err=>this.handleError(err))
  }
  getStudents(className,sectionName): Observable<any> {
    return this.http.get(`${this.basePath}?className=${className}&sectionName=${sectionName}`)
    .catch(err=>this.handleError(err))
  }




  addMarks(studentId:string,data:MarksModel): Observable<any> {
    return this.http.post(`${this.basePath}/${studentId}/marks`,data)
    .catch(err=>this.handleError(err))
  }
  getMarks(studentId:string): Observable<any> {
    return this.http.get(`${this.basePath}/${studentId}/marks`)
    .catch(err=>this.handleError(err))
  }
  deleteMarks(studentId:string,examName:string,subject:string): Observable<any> {
    return this.http.delete(`${this.basePath}/${studentId}/marks/${examName}/${subject}`)
    .catch(err=>this.handleError(err))
  }
  updateMarks(studentId:string,data:MarksModel): Observable<any> {
    return this.http.put(`${this.basePath}/${studentId}/marks`,data)
    .catch(err=>this.handleError(err))
  }

  addAttendence(data): Observable<any> {
    return this.http.post(`attendence`,data)
    .catch(err=>this.handleError(err))
  }
  getAttendence(date,className,sectionName): Observable<any> {
    return this.http.get(`attendence?date=${date}&className=${className}&sectionName=${sectionName}`)
    .catch(err=>this.handleError(err))
  }


  private handleError(err){
    console.log(err);
    let msg = err && err.error && err.error.msg ?err.error.msg:"Some thing unexpected"
    typeCancel(msg);
    return [err];
  }
}
