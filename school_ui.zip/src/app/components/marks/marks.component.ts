import { Component, OnInit, Input } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { StudentService } from '../../services/student/student.service';
import { StudentModel, MarksModel } from '../../models/student.model';
import { marks } from '../../config/tableSettings';
import { config } from '../../config/env';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.scss']
})
export class MarksComponent implements OnInit {

  public students: StudentModel[] = [];
  public source: LocalDataSource;
  public settings = marks;
  private className: string;
  private sectionName: string;
  public studentId: string;
  public selectModel : {name:string,_id:string}
  constructor(private _actRoute: ActivatedRoute, private _studentsService: StudentService) {

  }

  ngOnInit() {
    this._actRoute.params.subscribe(res => {
      this.className = res['className'];
      this.sectionName = res['sectionName'];
      this.settings = marks;
      this.getStudents();
    });
  }
  getStudents() {
    this._studentsService.getStudents(this.className, this.sectionName).subscribe(
      ({ data }) => this.students = data,
      err => console.log(err),
      () => console.log('complte getStudents() service')
    )
  }
  addMarks(data) {
    this._studentsService.addMarks(this.studentId, data).subscribe(
      ({ data }) => this.getMarks(),
      err => console.log(err),
      () => console.log('complte add marks() service')
    )
  }
  getMarks() {
    this._studentsService.getMarks(this.studentId).subscribe(
      ({ data }) => this.source = new LocalDataSource(data),
      err => console.log(err),
      () => console.log('complte getMarks() service')
    )
  }
  updateMarks(data) {
    this._studentsService.updateMarks(this.studentId, data).subscribe(
      ({ data }) => this.getMarks(),
      err => console.log(err),
      () => console.log('complte update students() service')
    )
  }
  deleteMarks(examName,subject) {
    this._studentsService.deleteMarks(this.studentId, examName,subject).subscribe(
      ({ data }) => this.getMarks(),
      err => console.log(err),
      () => console.log('complte delete students() service')
    )
  }
  onSelect(event) {
    if(event.value && event.value.length){
      let [{_id:studentId}]=event.value
      this.studentId=studentId;
      this.getMarks();
    }
  }
  onDeleteConfirm(event) {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
      this.deleteMarks(event.data.examName,event.data.subject);
    } else {
      event.confirm.reject();
    }
  }

  //  For confirm action On Save
  onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.confirm.resolve(event.newData);
      this.updateMarks(event.newData);
    } else {
      event.confirm.reject();
    }
  }

  //  For confirm action On Create
  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to create?')) {
      this.addMarks(event.newData);
      event.confirm.resolve(event.newData);
    } else {
      event.confirm.reject();
    }
  }

}
