import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-date-formattor',
  template: `{{renderValue | date : 'medium'}}`,
  styleUrls: []
})
export class DateFormattorComponent implements OnInit {
  renderValue: string;

  @Input() value: string;
  @Input() rowData: any;
  constructor() { }
  ngOnInit() {
    this.renderValue = this.value;
  }

}
