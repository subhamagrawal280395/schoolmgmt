import { Component, OnInit, ViewChild, ElementRef, AfterViewInit,OnDestroy,OnChanges } from '@angular/core';
import { Cell, DefaultEditor, Editor } from 'ng2-smart-table';

@Component({
  selector: 'app-date-picker-component',
  template: `<angular2-date-picker [(ngModel)]="date" (onDateSelect)="onDateSelect($event)"  [settings]="settings"></angular2-date-picker>`,
  styleUrls: []
})
export class DatePickerComponent extends DefaultEditor implements  OnInit {

  date: Date = new Date();
  settings = {
      bigBanner: true,
      defaultOpen: false,
      closeOnSelect:true,
      timePicker:true
  }
  constructor() { 
    super(); 
  }
  ngOnInit() {
    if(this.cell.getValue()){
      this.date=new Date(this.cell.getValue())
    }
  }
  onDateSelect(date:Date){
    this.cell.newValue=date.toISOString();
  }
}
