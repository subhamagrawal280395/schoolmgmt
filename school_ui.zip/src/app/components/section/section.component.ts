import { Component, OnInit, Input } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { StudentService } from '../../services/student/student.service';
import { StudentModel } from '../../models/student.model';
import { student } from '../../config/tableSettings';
import { config } from '../../config/env';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.scss']
})
export class SectionComponent implements OnInit {
  public students: StudentModel[] = [];
  public source: LocalDataSource;
  public settings = student;
  private className: string;
  private sectionName: string;
  constructor(private _actRoute: ActivatedRoute, private _studentsService: StudentService) {

  }

  ngOnInit() {
    this._actRoute.params.subscribe(res => {
      this.className = res['className'];
      this.sectionName = res['sectionName'];
      this.settings=student;
      this.getStudents();
    });
  }
  getStudents() {
    this._studentsService.getStudents(this.className, this.sectionName).subscribe(
      ({ data }) => this.source = new LocalDataSource(data),
      err => console.log(err),
      () => console.log('complte getStudents() service')
    )
  }

  updateStudent(id, data) {
    this._studentsService.updateStudent(id, data).subscribe(
      ({ data }) => this.getStudents(),
      err => console.log(err),
      () => console.log('complte update students() service')
    )
  }
  addStudent(data) {
    this._studentsService.addStudent({...data,className:this.className,sectionName:this.sectionName}).subscribe(
      ({ data }) => this.getStudents(),
      err => console.log(err),
      () => console.log('complte add students() service')
    )
  }
  deleteStudent(id) {
    this._studentsService.deleteStudent(id).subscribe(
      ({ data }) => this.getStudents(),
      err => console.log(err),
      () => console.log('complte delete students() service')
    )
  }
  onDeleteConfirm(event) {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
      this.deleteStudent(event.data.id);
    } else {
      event.confirm.reject();
    }
  }

  //  For confirm action On Save
  onSaveConfirm(event) {
    if (window.confirm('Are you sure you want to save?')) {
      event.confirm.resolve(event.newData);
      this.updateStudent(event.data.id,event.newData);
    } else {
      event.confirm.reject();
    }
  }

  //  For confirm action On Create
  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to create?')) {
      this.addStudent(event.newData);
      event.confirm.resolve(event.newData);
    } else {
      event.confirm.reject();
    }
  }
  onSearch(query: string = '') {
    if(query)
       this.source.setFilter([{field: 'name',search: query}],false);
    else
      this.source.setFilter([]);
  }

}
