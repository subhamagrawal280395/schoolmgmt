import { Component, OnInit, Input } from '@angular/core';
import { StudentService } from '../../services/student/student.service';
import { StudentModel, MarksModel } from '../../models/student.model';
import { config } from '../../config/env';
import { ActivatedRoute } from '@angular/router';
import { typeSuccess} from '../../config/sweet-alerts'

@Component({
  selector: 'app-attendence',
  templateUrl: './attendence.component.html',
  styleUrls: ['./attendence.component.scss']
})
export class AttendenceComponent implements OnInit {
  date:Date=new Date();
  presentStudents:string[]=[];
  presentId:string;
  public students: StudentModel[] = [];
  private className: string;
  private sectionName: string;
  constructor(private _actRoute: ActivatedRoute, private _studentsService: StudentService) {

  }

  ngOnInit() {
    this._actRoute.params.subscribe(res => {
      this.className = res['className'];
      this.sectionName = res['sectionName'];
      this.getStudents();
    });
  }
  getStudents() {
    this.presentStudents=[];
    this._studentsService.getStudents(this.className, this.sectionName).subscribe(
      ({ data }) => {
        this.students = data;
        this.getAttendence();
      },
      err => console.log(err),
      () => console.log('complte getStudents() service')
    )
  }
  getAttendence(){
    this.presentId=null;
    this._studentsService.getAttendence(this.date,this.className,this.sectionName)
    .subscribe(
      ({data})=>{
        console.log(data);
        if(data.presentStudents && data._id){
          this.presentId=data._id;
          this.presentStudents=data.presentStudents;
          this.presentStudents.forEach(id=>{
            let st = this.students.find(st=>st._id==id)
            if(st) st.isPresent=true;
          })
        }
      },
      err => console.log(err),
      () => console.log('complte get attendence() service')
    )
  }
  onCheckChange(id){
    let index= this.presentStudents.findIndex(s=>s==id);
    if(index==-1) this.presentStudents.push(id);
    else this.presentStudents.splice(index,1);
  }
  save(){
    this._studentsService.addAttendence({
      date:this.date,
      className:this.className,
      sectionName:this.sectionName,
      presentStudents:this.presentStudents,
      _id:this.presentId
    })
    .subscribe(
      (res) => typeSuccess("Success","Attendence uploaded successfully"),
      err => console.log(err),
      () => console.log('complte add attendence() service')
    )
  }

  dateChange(){
    this.students.forEach(st=>st.isPresent=false);
    this.getAttendence();
  }
}
