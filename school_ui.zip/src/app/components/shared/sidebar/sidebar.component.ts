import { Component, OnInit } from '@angular/core';
import { RouteInfo } from "./sidebar.metadata";
import { Router, ActivatedRoute } from "@angular/router";
import { TranslateService } from '@ngx-translate/core';
import { StudentService } from '../../../services/student/student.service';
import { StudentModel } from '../../../models/student.model';

declare var $: any;

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
})

export class SidebarComponent implements OnInit {
    public menuItems: RouteInfo[] = new Array<RouteInfo>();
    constructor(private router: Router,
        private route: ActivatedRoute, 
        public translate: TranslateService,
        public _studentService:StudentService
    ) {
        
    }

    ngOnInit() {
        $.getScript('./assets/js/app-sidebar.js');
        $.getScript('./assets/js/vertical-timeline.js');
        this._studentService.getSettings().subscribe(
            (res)=>{
                console.log(res);
                this._studentService.studentsSettings=res.data;
                this.createSideBarMetadata(res.data)
            },
            err=>console.log(err),
            ()=>console.log('complte getSettings() service')
        )
    }

    createSideBarMetadata({classNames,sectionsInfo}){
        Object.keys(classNames).forEach(name=>{
            let submenu=[];
            sectionsInfo[name].forEach(section=>{
                submenu.push({
                    path: ``, title: section, icon: '', class: 'has-sub', badge: '', badgeClass: '', isExternalLink: false, submenu: [
                        {path: `/class/${name}/section/${section}/list`, title: "Students", icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false,submenu:[]},
                        {path: `/class/${name}/section/${section}/marks`, title: "Marks", icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false,submenu:[]},
                        {path: `/class/${name}/section/${section}/attendence`, title: "Attendence", icon: '', class: '', badge: '', badgeClass: '', isExternalLink: false,submenu:[]}
                    ]
                })
            });
            this.menuItems.push( {
                path: '', 
                title: name, 
                icon: 'icon-calculator', 
                badge: '', 
                class: 'has-sub',
                badgeClass: 'badge badge-pill badge-danger', 
                isExternalLink: false, 
                submenu:submenu
            });
        })
        console.log(this.menuItems)
    }

    //NGX Wizard - skip url change
    ngxWizardFunction(path: string) {
        if (path.indexOf('forms/ngx') !== -1)
            this.router.navigate(['forms/ngx/wizard'], { skipLocationChange: false });
    }
}
