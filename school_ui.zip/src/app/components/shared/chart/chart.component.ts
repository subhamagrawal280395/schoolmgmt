import { Component, OnInit, Input } from '@angular/core';
@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.scss']
})
export class ChartComponent implements OnInit {
  @Input() barChartData =[] ;

  //Bar Charts
  barChartView: any[] = [1000, 1000];

  // options
  barChartShowYAxis = true;
  barChartShowXAxis = true;
  barChartGradient = false;
  barChartShowLegend = false;
  barChartShowXAxisLabel = true;
  barChartXAxisLabel = 'Sessions'
  barChartShowYAxisLabel = true
  barChartYAxisLabel = 'Likes';
  barChartColorScheme = {
    domain: ['#009DA0', '#FF8D60', '#FF586B', '#AAAAAA']
  }
  constructor() { }

  ngOnInit() {
  }

}
