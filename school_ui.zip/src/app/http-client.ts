import {Injectable} from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { config } from './config/env';

@Injectable()
export class HttpClientService {

  constructor(private http: HttpClient) {}

  get(url:string, data:any={}) {
    url = config.apiBaseUrl + url;
    let headers= new HttpHeaders()
    return this.http.get(url, {headers});
  }
  put(url:string, data:any={}) {
    url = config.apiBaseUrl + url;
    let headers= new HttpHeaders()
    return this.http.put(url,data, {headers});
  }
  delete(url:string, data:any={}) {
    url = config.apiBaseUrl + url;
    let headers= new HttpHeaders()
    return this.http.delete(url, {headers});
  }



  post(url:string, data:any,token:string="",contentType:string='application/json') {
    url = config.apiBaseUrl + url;
    let headers= new HttpHeaders()
    return this.http.post(url, data, {headers});
  }

}