import { Routes, RouterModule } from '@angular/router';


import { HomeComponent } from './components/home/home.component';
import { SectionComponent } from './components/section/section.component';
import { MarksComponent } from './components/marks/marks.component';
import { AttendenceComponent } from './components/attendence/attendence.component';


//import { LoginGuard } from './guards/login.guard';

const appRoutes: Routes = [
    { path: '', component: HomeComponent  ,children:[
        { path: 'class/:className/section/:sectionName/list', component: SectionComponent },
        { path: 'class/:className/section/:sectionName/marks', component: MarksComponent },
        { path: 'class/:className/section/:sectionName/attendence', component: AttendenceComponent }
    ] },
    { path: 'home', component: HomeComponent },

    // otherwise redirect to home
    { path: '**', redirectTo: 'home' }
];

export const routing = RouterModule.forRoot(appRoutes);