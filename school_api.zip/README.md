# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* getvokl api for mobile and web

### for running app ### 
*  npm install
* ./bin/www
* mongod should be running

## for running in the background ###
* npm run startDev
* then
* npm run stopDev

### For running unit tests ###
* npm install mocha -g
* for first time mocha --timeout 50000 so that fake mongoose can initialize
* next time mocha