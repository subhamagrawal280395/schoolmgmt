const createThumb = require('node-thumbnail').thumb;
const config = require('../../config/config');
const moment = require('moment');
const emailValidatorRegex =  /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
const bcrypt = require('bcrypt-nodejs');
const MONTHS_ENUM = [
    {short:"JAN",long:"JANUARY" },
    {short:"FEB",long:"FEBRUARY" },
    {short:"MAR",long:"MARCH" },
    {short:"APR",long:"APRIL" },
    {short:"MAY",long:"MAY" },
    {short:"JUN",long:"JUNE" },
    {short:"JUL",long:"JULY" },
    {short:"AUG",long:"AUGUST" },
    {short:"SEP",long:"SEPTEMBER" },
    {short:"OCT",long:"OCTOBER" },
    {short:"NOV",long:"NOVEMBER" },
    {short:"DEC",long:"DECEMBER" }
]
const DAYS_ENUM = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]
exports.getValidPageAndLimit = (page,limit,maxAllowedLimit=200)=>{
    page=+page || 1;
    limit = +limit || maxAllowedLimit;
    if(page<1) page = 1;
    if(limit<1 || limit>maxAllowedLimit) limit=maxAllowedLimit;

    return {page,limit,skip:(page-1)*limit};
}

//sorts and join  objectIds by "|" seperator
exports.getSorteIdsStr=(...objectIds)=> objectIds.map(oid=>oid+"").sort().join("|");


//generate thumb for image
exports.makeThumb = (sourcepath,destinationPath=config.multerSettings.storagePathLocal,concurrency=4,width=300)=>{
    return new Promise((resolve,reject)=>{
        createThumb({
            source: sourcepath,
            destination: destinationPath,
            concurrency: concurrency,
            width: width
          }, (files, err, stdout, stderr)=> {
            if(err || stderr) reject(err || stderr);
            else resolve(files);
        });
    });  
}

exports.getRandomString = ()=> `${Date.now()}${Math.floor(Math.random()*89999+10000)}`

exports.getUrlByKey = (key,aggregatePipe=false) =>{
    if(aggregatePipe){
        return {
           $cond:[key,{$concat:[config.aws.baseMediaStorageUrl,"/",key]},key]
        }
    }
    return `${config.aws.baseMediaStorageUrl}/${key}`

}

exports.getTimeDiffQuery = ()=> {
    return {$gte:moment().subtract(config.conversation.countdownTimer,config.conversation.countdownTimerUnit).toDate()};
}

exports.parseJSON = str=>{
    return new Promise((resolve,reject)=>{
        let parsedObj ;
        try{
            parsedObj = JSON.parse(str);
            resolve(parsedObj);
        }
        catch(err){
            logger.info(err);
            reject("Error while parsing json");
        }
    });
}

exports.getValidTime= (timeStr,format= moment.ISO_8601)=>{
    if(!timeStr ||  !moment(timeStr,format, true).isValid()){
        return new Date();
    }
    return new Date(timeStr);
}

exports.emailValidator = (...emails)=>{
    return emails.every(email=> typeof 'string' && emailValidatorRegex.test(email) );
}

exports.getMonthStrings=date=>{
    return {$arrayElemAt: [ MONTHS_ENUM , { $subtract: [ {$month:date}, 1 ] } ]}
}
exports.getDayName = date =>{
    return {$arrayElemAt: [ DAYS_ENUM , { $subtract: [ {$dayOfWeek:date}, 1 ] } ]}
}

exports.handleRequest = ({res,statusCode=200,err="error",msg='',data={},result=1})=>{
    if(result){
        return res.status(statusCode).send({result:result,msg:msg,data:data});
    }
    return res.status(statusCode).send({result:result,msg:err instanceof Error ? err.message:err});
}
exports.getEncryptedPassword = function (password) {
    return new Promise((resolve,reject)=>{
        bcrypt.genSalt(5, function (err, salt) {
            if (err) return reject(err);
            bcrypt.hash(password, salt, null, function (err, hash) {
                if (err) return reject(err);
                resolve(hash);
            });
        });
    })
};

exports.generateRandomColor = ()=>`#${Math.random().toString(16).substr(-6)}`