//var Log = require('log'), log = new Log();
// Bring Mongoose into the app
var mongoose = require( 'mongoose' );
var config=require('../config/config'); //for db connection strings and settings  
// Create the database connection
var db = mongoose.createConnection(config.db.master,config.db.options);


// CONNECTION EVENTS


// When successfully connected
db.on('connected', function () {
  logger.info('Mongoose connection open to master DB');       
});

// If the connection throws an error
db.on('error',function (err) {
  logger.debug('Mongoose connection error for master DB: ' + err);
});

// When the connection is disconnected
db.on('disconnected', function () {
  logger.debug('Mongoose connection disconnected for master DB');
});

//When connection is reconnected
db.on('reconnected', function () {
  logger.info('Mongoose connection reconnected for master DB');
});
// If the Node process ends, close the Mongoose connection
process.on('SIGINT', function() {
  db.close(function () {
    logger.debug('Mongoose connection disconnected for master DB through app termination');
    process.exit(0);
  });
});

module.exports = db;
