let Student = require('../models/studentModel');
let Promise = require('bluebird');
const config = require('../config/config')
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;

exports.create  = data => new Student(data).save();

exports.getStudentsBySection = ({className,sectionName})=>Student.find({className,sectionName},{marks:0})

exports.delete = _id =>Student.deleteOne({_id})

exports.update = (_id,{name,birthDate})=>Student.update({_id},{$set:{name,birthDate}},{runValidators:true})


//Services related to marks

exports.addMarks = (_id,{examName,subject,gained,total})=>Student.update({_id},{$push:{marks:{examName,subject,total,gained}}},{runValidators:true})

exports.updateMarks = (_id,{examName,subject,gained,total})=>Student.update({_id,marks:{$elemMatch:{examName,subject}}},{$set:{"marks.$":{examName,subject,total,gained}}},{runValidators:true})

exports.getMarks = _id => Student.aggregate([
    {$match:{_id:ObjectId(_id)}},
    {$unwind:"$marks"},
    {$replaceRoot:{newRoot:"$marks"}}
])

exports.deleteMarks = (_id,examName,subject)=>Student.update({_id},{$pull:{marks:{examName,subject}}},{runValidators:true});

exports.isExamGiven = (_id,examName,subject)=>Student.count({_id,marks:{$elemMatch:{examName,subject}}});

