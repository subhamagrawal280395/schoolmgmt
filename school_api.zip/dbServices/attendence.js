let Attendence = require('../models/presenceModel');
let Promise = require('bluebird');
const config = require('../config/config')
const mongoose = require('mongoose');
const ObjectId = mongoose.Types.ObjectId;
const moment = require('moment');


exports.update = ({ date, _id, className, sectionName, presentStudents }) => {
    if (_id) {
        return Attendence.update(
            { date: moment(date).format('YYYY/MM/DD'), "presence._id": _id },
            { $set: { "presence.$": { className, sectionName, presentStudents,_id } } },
            { runValidators: true }
        )
    }
    return Attendence.update(
        { date: moment(date).format('YYYY/MM/DD') },
        { $push: { "presence": { className, sectionName, presentStudents } } },
        { runValidators: true, upsert: true }
    )

}

exports.get = (date, className, sectionName) => {
    return Attendence.aggregate([
    {
        $match: { date: moment(date).format('YYYY/MM/DD') }
    },
    {
        $project: {
            presence: {
                $filter: {
                    input: "$presence",
                    as: "p",
                    cond: { $and: [{ $eq: ["$$p.className", className] }, { $eq: ["$$p.sectionName", sectionName] }] }
                }
            }
        }
    },
    {
        $unwind: "$presence"
    },
    {
        $replaceRoot: { newRoot: "$presence" }
    }
])
}

