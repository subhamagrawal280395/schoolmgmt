require('dotenv-safe').load();
var express = require('express');
var expressValidator = require('express-validator');
var helmet = require('helmet');
var path = require('path');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
const compression = require('compression');
const config     = require('./config/config.js');
//winston logger available in whole app
logger = require('./common/middlewares/logger');

var routes = require('./routes/index');


var app = express();
app.set('trust proxy', true); 
app.use(helmet());
app.use(function(req, res, next) {
  if (req.headers['x-amz-sns-message-type']) {
      req.headers['content-type'] = 'application/json;charset=UTF-8';
  }
  next();
});
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({ extended: true ,limit: '50mb' }));
function blockHTTP(req, res,next){
  if(req.headers['x-forwarded-proto'] && req.headers['x-forwarded-proto'] === "http") {
    return res.status(403).send({msg: "Cannot access via HTTP"});
  }
  else {
    next();
  }
}
if(config.blockHttp===true){
  app.use(blockHTTP);
}
app.options("*",function(req,res,next){
  res.header("Access-Control-Allow-Origin", req.get("Origin")||"*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type,Authorization, Accept");
  res.header("Access-Control-Allow-Methods","POST, GET, PUT, DELETE, OPTIONS");
  res.status(200).end();
});

app.use(require("morgan")(function (tokens, req, res) {
  let ip = req.header('x-forwarded-for') || req.connection.remoteAddress;
  return [
    req.user && req.user._id,
    ip,
    tokens['remote-user'](req,res),
    tokens.date(req, res, 'clf'),
    tokens.method(req, res),
    tokens.url(req, res),
    tokens.status(req, res),
    tokens.res(req, res, 'content-length'), '-',
    tokens['referrer'](req, res),
    tokens['user-agent'](req, res),
    tokens['response-time'](req, res), 'ms'
  ].join(' ')
}, { "stream": logger.stream }));

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
    next();
});
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');
app.use(compression());
app.use(expressValidator());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/v1', routes);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found any api');
  err.status = 404;
  next(err);
});


app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
