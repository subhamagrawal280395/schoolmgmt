if (localStorage.getItem("token")) {
    location.href = "/dashboard";
}
let redirectionUrl = "/";
let anchors = document.getElementsByClassName('open-pop-up');
for (let i = 0; i < anchors.length; i++) anchors[i].onclick = openPopUp;

function openPopUp(event){
    event.preventDefault();
    redirectionUrl = event.target.href || event.path[1].href;
    console.log(event, redirectionUrl);
    showPopUp();
    showBackDrop();
}
const redirectionHandler = () => {
    resetErrorMessage();
    FB.login(function (response) {
        if (response.status === 'connected') {
            // Logged into your app and Facebook.

            var accessToken = response.authResponse.accessToken;
            var params = "token=" + accessToken;

            var http = new XMLHttpRequest();
            var url = "/api/users/social-login";
            http.open("POST", url, true);

            //Send the proper header information along with the request
            http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

            http.onreadystatechange = function () { //Call a function when the state changes.
                if (http.readyState == 4) {
                    if (http.status == 200) {
                        var apiResponse = JSON.parse(http.responseText);
                        var token = apiResponse.data.token;
                        localStorage.setItem("token", token);
                        location.href=redirectionUrl;
                    } else {
                        addErrorMessage("Failed to login into GetVokl");
                    }
                }
            }
            http.send(params);
        } else {
            // The person is not logged into this app or we are unable to tell.
            addErrorMessage("Failed to authenticate Facebook account")
        }
    });
}
const showBackDrop = () => {
    let backdropID = document.getElementById("backdrop")
    backdropID.classList.remove("display-none");
    backdropID.classList.add("display-block");
}
const showPopUp = () => {
    closeTrendingVokls();
    let popUp = document.getElementById("loginPopup");
    popUp.classList.add('display-block');
    popUp.classList.remove('display-none');
    document.getElementById('wrapper').classList.add('tour-mob-overflow');
}
const showList = (id) => {
    let div = document.getElementById(id)
    div.classList.add("open");
}
const showCodeOfConduct = () => {
    let div = document.getElementById("codeOfConduct")
    div.classList.add("open");
}
const hideBackDrop = () => {
    let backdropID = document.getElementById("backdrop")
    backdropID.classList.add("display-none");
    backdropID.classList.remove("display-block");
}
const hidePopUp = () => {
    let popUp = document.getElementById("loginPopup");
    popUp.classList.remove('display-block');
    popUp.classList.add('display-none');
    document.getElementById('wrapper').classList.remove('tour-mob-overflow');
}
const hideList = () => {
    let div = document.getElementById("hamburgerIcon")
    div.classList.remove("open");
    div = document.getElementById("listDropUp")
    div.classList.remove("open");
}
const hideCodeOfConduct = () => {
    let div = document.getElementById("codeOfConduct")
    div.classList.remove("open");
}
const openHamburgerList = (event,id) => {
    if (["icon-hamburger", "icon-settings" ,"btn dropdown-toggle"].indexOf(event.target.className) != -1) {
        closeTrendingVokls();
        showList(id);
        showBackDrop();
    }
}

const backdropClick = (event) => {
    if (event.target.id == "backdrop") {
        hideList()
        hideBackDrop();
        hidePopUp();
        hideCodeOfConduct();
    }
}

const toggleTrendingVokls = () => {
    hidePopUp();
    // var trendingVoklList = document.getElementById("trandingvoklList");
    // if (trendingVoklList.classList.contains("openleftsideCntr")) {
    //     trendingVoklList.classList.remove("openleftsideCntr");
    // }
    // else {
    //     trendingVoklList.classList.add("openleftsideCntr");
    // }
}
const closeTrendingVokls = () => {
    hidePopUp();
    var trendingVoklList = document.getElementById("trandingvoklList");
    if (trendingVoklList.classList.contains("openleftsideCntr")) {
        trendingVoklList.classList.remove("openleftsideCntr");
    }
}
const openCodeOfConduct = () => {
    showCodeOfConduct();
    showBackDrop();
}


const addErrorMessage = message => {
    document.getElementById("login-error").innerHTML = message;
    document.getElementById("login-error").classList.remove('hidden');
}

const resetErrorMessage = () => {
    document.getElementById("login-error").innerHTML = "";
    document.getElementById("login-error").classList.add('hidden');
}