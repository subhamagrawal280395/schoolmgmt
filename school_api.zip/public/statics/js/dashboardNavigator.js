(function(){
    // steps should always in sequence
    const steps = ["step6","step4","step3","step2","step1"];

    const doNavigation = event =>{
        let id = event.currentTarget.id;
        let stepIndex = steps.indexOf(id);
        if(stepIndex!=-1){
            let previousOverlayDiv = document.getElementById(`${steps[stepIndex]}Overlay`);
            previousOverlayDiv && previousOverlayDiv.classList.remove('tour-overlay');
            previousOverlayDiv && document.getElementsByClassName('onboarding-overlay')[0].classList.remove('hidden');
            let previousTextOverlay =document.getElementsByClassName(`${steps[stepIndex]}TextOverlay`)[0]
            previousTextOverlay && previousTextOverlay.classList.remove('tour-overlay-text');
            // previousOverlayDiv && document.getElementsByClassName('trandingvoklBar')[0].classList.remove('tour-trending-vokls-left');
            //previousOverlayDiv && document.getElementsByClassName('trandingvoklBar')[0].classList.add('pug-trendingvokl');
            if(steps[stepIndex+1]=="step1"){
                document.getElementsByClassName('dashboardBar')[0].classList.add('tour-show-content')
                document.getElementsByClassName('tour-overlay')[0].classList.remove('hidden')
                document.getElementsByClassName('onboarding-overlay')[0].classList.add('hidden');
            }
            if(steps[stepIndex]=="step1"){
                document.getElementsByClassName('dashboardBar')[0].classList.remove('tour-show-content')
                document.getElementsByClassName('tour-overlay')[0].classList.add('hidden')
                document.getElementsByClassName('onboarding-overlay')[0].classList.add('hidden');
            }

            document.getElementsByClassName('content-space')[0].classList.remove('hidden')
            document.getElementById('onboarding-overlay-step').classList.add('hidden')
            
            //last step
            if(stepIndex==steps.length-1){
                //hide overlay
                document.getElementsByTagName('header')[0].classList.remove('tour-header');
                document.getElementById('tourOverlay').classList.add('hidden');
                document.getElementsByClassName('onboarding-overlay')[0].classList.add('hidden');
                document.getElementsByClassName('mob-footer-menu')[0].classList.remove("tour-footer-menu");
                enableAddCalendar();
            }
            else{
                //navigate further;
                document.getElementsByClassName(id)[0].classList.add('hidden');
                document.getElementsByClassName(steps[stepIndex+1])[0].classList.remove('hidden')
                let currentOverlayDiv = document.getElementById(`${steps[stepIndex+1]}Overlay`);
                currentOverlayDiv && currentOverlayDiv.classList.add('tour-overlay');
                currentOverlayDiv && document.getElementsByClassName('onboarding-overlay')[0].classList.add('hidden');
                let currentTextOverlay =document.getElementsByClassName(`${steps[stepIndex+1]}TextOverlay`)[0]
                currentTextOverlay && currentTextOverlay.classList.add('tour-overlay-text');
                // currentOverlayDiv && document.getElementsByClassName('trandingvoklBar')[0].classList.add('tour-trending-vokls-left');
                //currentOverlayDiv && document.getElementsByClassName('trandingvoklBar')[0].classList.remove('pug-trendingvokl');
            }
        }
    }

    if(!localStorage.getItem('isDashboardTourViewed')){
        document.getElementById('tourOverlay').classList.remove('hidden');
        document.getElementsByClassName('onboarding-overlay')[0].classList.remove('hidden');
        document.getElementsByTagName('header')[0].classList.add('tour-header')
        // document.getElementsByClassName('trandingvoklBar')[0].classList.add('tour-trending-vokls-left');
        //document.getElementsByClassName('trandingvoklBar')[0].classList.remove('pug-trendingvokl');
        localStorage.setItem('isDashboardTourViewed',JSON.stringify(true));
        document.getElementsByClassName('mob-footer-menu')[0].classList.add("tour-footer-menu");

        
        window.addEventListener('load',function(){
            steps.forEach((step)=>{
                let stepOverlay = document.getElementById(step);
                stepOverlay.addEventListener('click',doNavigation);
            })
        })
    }
    else{
        enableAddCalendar();
    }
    function enableAddCalendar(){
        var addCalButtons =  document.getElementsByClassName('addeventatc');
        for(let i=0;addCalButtons.length;i++) addCalButtons[i].classList.remove('disabled-cal-button');
    }
})();