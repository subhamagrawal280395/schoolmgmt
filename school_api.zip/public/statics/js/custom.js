// Ready function
$(document).ready(function(e) {	
	$('.count-number-dropdow .custom-dropdown-cnt ul').on('click', function(event){
		event.stopPropagation();
	});	
	$('.vokls-chat-icon').click(function(){
		$('.chat-overlay').addClass('active');
		$('.vokls-profile-chat').addClass('open-profile-chat');
		$('body').addClass('overflow-hidden');
	})
	$('.chat-overlay, .vokls-profile-chat .vokls-chat-closed').click(function(){
		$('.chat-overlay').removeClass('active');
		$('.vokls-profile-chat').removeClass('open-profile-chat');
		$('body').removeClass('overflow-hidden');
	})

	/*Trading Vokls*/
	$('.mob-footer-menu ul li a.ftrading-vokls').click(function(){
		// $(this).toggleClass('active');		
		$('.vokls-profile-chat').removeClass('open-profile-chat');
		$('.header-search').removeClass('open-header-search');
		$('.leftsideCntr.trandingvoklBar').toggleClass('openleftsideCntr');
	})
	$('.leftsideCntr .vokls-chat-closed').click(function(){
		$('.leftsideCntr.trandingvoklBar').removeClass('openleftsideCntr');
		$('.mob-footer-menu ul li a.ftrading-vokls').removeClass('active');
		$('body').removeClass('overflow-hidden');
	})

	/*Friend chat*/
	$('.mob-footer-menu ul li a.vokl-chat-live').click(function(){
		// $(this).toggleClass('active');				
		$('.header-search').removeClass('open-header-search');
		$('.leftsideCntr.trandingvoklBar').removeClass('openleftsideCntr');
		$('.vokls-profile-chat').toggleClass('open-profile-chat');		
	})
	$('.vokls-profile-chat .vokls-chat-closed').click(function(){
		$('.vokls-profile-chat').removeClass('open-profile-chat');
		$('.mob-footer-menu ul li a.vokl-chat-live').removeClass('active');
		$('body').removeClass('overflow-hidden');
	})

	/*Search*/
	$('.mob-footer-menu ul li a.search-item').click(function(){
		// $(this).toggleClass('active');				
		$('.leftsideCntr.trandingvoklBar').removeClass('openleftsideCntr');
		$('.vokls-profile-chat').removeClass('open-profile-chat');
		$('.header-search').toggleClass('open-header-search');
	})
	$('.header-search .vokls-chat-closed').click(function(){
		$('.header-search').removeClass('open-header-search');
		$('.mob-footer-menu ul li a.search-item').removeClass('active');
		$('body').removeClass('overflow-hidden');
	})

	/*mobile setting menu*/	
	$('#mobtabmenu').click(function(){
		$('body').removeClass('overflow-hidden');
		$('.mob-footer-menu ul li a.m-menu').removeClass('active');
		$('.vokls-profile-chat').removeClass('open-profile-chat');
		$('.header-search').removeClass('open-header-search');
		$('.leftsideCntr.trandingvoklBar').removeClass('openleftsideCntr');
	})

	/*mobile menu  active*/
	$('.mob-footer-menu ul li a.m-menu').each(function(){
		$(this).click(function(){
			$('body').addClass('overflow-hidden');
			$(this).toggleClass('active');
			$(this).parents('li').siblings('li').find('a.m-menu').removeClass('active');
		})
		
	})

	// $('.mob-footer-menu ul li a.ftrading-vokls').click(function(){
	// 	$('.leftsideCntr.trandingvoklBar').addClass('openleftsideCntr');
	// })

	$('.leftsideCntr .vokls-chat-closed').click(function(){
		$('.leftsideCntr.trandingvoklBar').removeClass('openleftsideCntr');
	})

	
	

	$('.mob-footer-menu ul li a.ftrading-vokls').click(function(){
		$('.leftsideCntr.leftsideContSm').addClass('openleftsideContSm');
	})
	$('.leftsideCntr .vokls-chat-closed').click(function(){
		$('.leftsideContSm').removeClass('openleftsideContSm');
	})


	$('#talkmodal').modal('show');


	$('.trandingvoklBar, .curatetabBar, .leftsideContSm').scrollToFixed({
		marginTop: $('.headerCntr').outerHeight(true) + 35
	});

	$('.report-info .report-links').click(function(){
		$('.report-information').removeClass('hidden');
	})
	$('.report-information .icon-delete').click(function(){
		$(this).parents('.report-information').addClass('hidden');
	})

	$('.comment-expresion ul li .expression-links').click(function(){
		$('.animated-thumb').addClass('selected');
		setTimeout(function(){
			$('.animated-thumb').addClass('movetop'); 
		}, 1000);
	})

	$('.custom-checkbox-label input[type="checkbox"]').click(function(){
		if($(this).is(":checked")) {
			$(this).parents('label').addClass('active');
		}
		else if($(this).is(":not(':checked')")) {
			$(this).parents('label').removeClass('active');			
		}
	})

	$('.voklsprofile-block .profile-infomation .profile-edits .save-edits').hide();
	$('.voklsprofile-block .profile-infomation .profile-edits .icons').click(function(){		
		$(this).hide();
		$('.voklsprofile-block .profile-infomation .profile-edits .save-edits').show();

		$('.voklsprofile-block .profile-infomation .profile-infomation-name .profile-edit-name').addClass('hidden');
		$('.voklsprofile-block .profile-infomation .profile-info-textbox').removeClass('hidden');
	})
	$('.voklsprofile-block .profile-infomation .profile-edits .save-edits').click(function(){		
		$(this).hide();
		$('.voklsprofile-block .profile-infomation .profile-edits .icons').show();
		$('.voklsprofile-block .profile-infomation .profile-infomation-name .profile-edit-name').removeClass('hidden');
		$('.voklsprofile-block .profile-infomation .profile-info-textbox').addClass('hidden');
	})
	$('.header-search .vokls-search .form-control-search').click(function(){
		$(this).parents('.vokls-search').siblings('.VoklsSearchResult').toggleClass('hidden');
	})	

	$('.v2-login-tab ul li.signin a').click(function(){
		$('.v2-login-tab ul li').removeClass('active');
		$(this).parents('li').addClass('active');
		$('#sign-in-box').removeClass('hidden');
		$('#explore-public-box').addClass('hidden');
	}); 
		
	
	$('.v2-login-tab ul li.explore a').click(function(){
		$('.v2-login-tab ul li').removeClass('active');
		$(this).parents('li').addClass('active');		
		$('#explore-public-box').removeClass('hidden')
		$('#sign-in-box').addClass('hidden')
	}) 
});

/*Fixed scroll js*/
(function(a){a.isScrollToFixed=function(b){return !!a(b).data("ScrollToFixed")};a.ScrollToFixed=function(d,i){var m=this;m.$el=a(d);m.el=d;m.$el.data("ScrollToFixed",m);var c=false;var H=m.$el;var I;var F;var k;var e;var z;var E=0;var r=0;var j=-1;var f=-1;var u=null;var A;var g;function v(){H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed");f=-1;E=H.offset().top;r=H.offset().left;if(m.options.offsets){r+=(H.offset().left-H.position().left)}if(j==-1){j=r}I=H.css("position");c=true;if(m.options.bottom!=-1){H.trigger("preFixed.ScrollToFixed");x();H.trigger("fixed.ScrollToFixed")}}function o(){var J=m.options.limit;if(!J){return 0}if(typeof(J)==="function"){return J.apply(H)}return J}function q(){return I==="fixed"}function y(){return I==="absolute"}function h(){return !(q()||y())}function x(){if(!q()){var J=H[0].getBoundingClientRect();u.css({display:H.css("display"),width:J.width,height:J.height,"float":H.css("float")});cssOptions={"z-index":m.options.zIndex,position:"fixed",top:m.options.bottom==-1?t():"",bottom:m.options.bottom==-1?"":m.options.bottom,"margin-left":"0px"};if(!m.options.dontSetWidth){cssOptions.width=H.css("width")}H.css(cssOptions);H.addClass(m.options.baseClassName);if(m.options.className){H.addClass(m.options.className)}I="fixed"}}function b(){var K=o();var J=r;if(m.options.removeOffsets){J="";K=K-E}cssOptions={position:"absolute",top:K,left:J,"margin-left":"0px",bottom:""};if(!m.options.dontSetWidth){cssOptions.width=H.css("width")}H.css(cssOptions);I="absolute"}function l(){if(!h()){f=-1;u.css("display","none");H.css({"z-index":z,width:"",position:F,left:"",top:e,"margin-left":""});H.removeClass("scroll-to-fixed-fixed");if(m.options.className){H.removeClass(m.options.className)}I=null}}function w(J){if(J!=f){H.css("left",r-J);f=J}}function t(){var J=m.options.marginTop;if(!J){return 0}if(typeof(J)==="function"){return J.apply(H)}return J}function B(){if(!a.isScrollToFixed(H)||H.is(":hidden")){return}var M=c;var L=h();if(!c){v()}else{if(h()){E=H.offset().top;r=H.offset().left}}var J=a(window).scrollLeft();var N=a(window).scrollTop();var K=o();if(m.options.minWidth&&a(window).width()<m.options.minWidth){if(!h()||!M){p();H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed")}}else{if(m.options.maxWidth&&a(window).width()>m.options.maxWidth){if(!h()||!M){p();H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed")}}else{if(m.options.bottom==-1){if(K>0&&N>=K-t()){if(!L&&(!y()||!M)){p();H.trigger("preAbsolute.ScrollToFixed");b();H.trigger("unfixed.ScrollToFixed")}}else{if(N>=E-t()){if(!q()||!M){p();H.trigger("preFixed.ScrollToFixed");x();f=-1;H.trigger("fixed.ScrollToFixed")}w(J)}else{if(!h()||!M){p();H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed")}}}}else{if(K>0){if(N+a(window).height()-H.outerHeight(true)>=K-(t()||-n())){if(q()){p();H.trigger("preUnfixed.ScrollToFixed");if(F==="absolute"){b()}else{l()}H.trigger("unfixed.ScrollToFixed")}}else{if(!q()){p();H.trigger("preFixed.ScrollToFixed");x()}w(J);H.trigger("fixed.ScrollToFixed")}}else{w(J)}}}}}function n(){if(!m.options.bottom){return 0}return m.options.bottom}function p(){var J=H.css("position");if(J=="absolute"){H.trigger("postAbsolute.ScrollToFixed")}else{if(J=="fixed"){H.trigger("postFixed.ScrollToFixed")}else{H.trigger("postUnfixed.ScrollToFixed")}}}var D=function(J){if(H.is(":visible")){c=false;B()}else{l()}};var G=function(J){(!!window.requestAnimationFrame)?requestAnimationFrame(B):B()};var C=function(){var K=document.body;if(document.createElement&&K&&K.appendChild&&K.removeChild){var M=document.createElement("div");if(!M.getBoundingClientRect){return null}M.innerHTML="x";M.style.cssText="position:fixed;top:100px;";K.appendChild(M);var N=K.style.height,O=K.scrollTop;K.style.height="3000px";K.scrollTop=500;var J=M.getBoundingClientRect().top;K.style.height=N;var L=(J===100);K.removeChild(M);K.scrollTop=O;return L}return null};var s=function(J){J=J||window.event;if(J.preventDefault){J.preventDefault()}J.returnValue=false};m.init=function(){m.options=a.extend({},a.ScrollToFixed.defaultOptions,i);z=H.css("z-index");m.$el.css("z-index",m.options.zIndex);u=a("<div />");I=H.css("position");F=H.css("position");k=H.css("float");e=H.css("top");if(h()){m.$el.after(u)}a(window).bind("resize.ScrollToFixed",D);a(window).bind("scroll.ScrollToFixed",G);if("ontouchmove" in window){a(window).bind("touchmove.ScrollToFixed",B)}if(m.options.preFixed){H.bind("preFixed.ScrollToFixed",m.options.preFixed)}if(m.options.postFixed){H.bind("postFixed.ScrollToFixed",m.options.postFixed)}if(m.options.preUnfixed){H.bind("preUnfixed.ScrollToFixed",m.options.preUnfixed)}if(m.options.postUnfixed){H.bind("postUnfixed.ScrollToFixed",m.options.postUnfixed)}if(m.options.preAbsolute){H.bind("preAbsolute.ScrollToFixed",m.options.preAbsolute)}if(m.options.postAbsolute){H.bind("postAbsolute.ScrollToFixed",m.options.postAbsolute)}if(m.options.fixed){H.bind("fixed.ScrollToFixed",m.options.fixed)}if(m.options.unfixed){H.bind("unfixed.ScrollToFixed",m.options.unfixed)}if(m.options.spacerClass){u.addClass(m.options.spacerClass)}H.bind("resize.ScrollToFixed",function(){u.height(H.height())});H.bind("scroll.ScrollToFixed",function(){H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed");B()});H.bind("detach.ScrollToFixed",function(J){s(J);H.trigger("preUnfixed.ScrollToFixed");l();H.trigger("unfixed.ScrollToFixed");a(window).unbind("resize.ScrollToFixed",D);a(window).unbind("scroll.ScrollToFixed",G);H.unbind(".ScrollToFixed");u.remove();m.$el.removeData("ScrollToFixed")});D()};m.init()};a.ScrollToFixed.defaultOptions={marginTop:0,limit:0,bottom:-1,zIndex:1000,baseClassName:"scroll-to-fixed-fixed"};a.fn.scrollToFixed=function(b){return this.each(function(){(new a.ScrollToFixed(this,b))})}})(jQuery);


// Function for equal height parallel blocks

equalheight = function(container){
	var currentTallest = 0,
	    currentRowStart = 0,
	    rowDivs = new Array(),
	    $el,
	    topPosition = 0;
 	$(container).each(function() {
	   	$el = $(this);
	   	$($el).height('auto')
	   	topPostion = $el.position().top;
	   	if (currentRowStart != topPostion) {
	    	for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
	       		rowDivs[currentDiv].height(currentTallest);
	     	}
	     	rowDivs.length = 0; // empty the array
	     	currentRowStart = topPostion;
	     	currentTallest = $el.height();
	     	rowDivs.push($el);
	   	} else {
	    	rowDivs.push($el);
	     	currentTallest = (currentTallest < $el.height()) ? ($el.height()) : (currentTallest);
	  	}
	   	for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
	    	rowDivs[currentDiv].height(currentTallest);
	   	}
 	});
}

function equalheightapply(){
    equalheight('.vokls-place-holder-block .min-height');    
    
}


// Load function
$(window).load(function(){

	$('.vokls-donate-time').addClass('open-donate-time');
	setTimeout(function(){
		$('.vokls-donate-time.open-donate-time').addClass('move-donate-time');
	}, 2000);

});

// Load and Scroll function
$(window).bind("load scroll", function() {

});

// Load and Resize function
$(window).bind("load resize", function() {
    sizingheight();
    equalheightapply();  
});


// Height Calculation
function sizingheight(){

}


