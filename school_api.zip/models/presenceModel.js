const mongoose = require('mongoose');
Schema = mongoose.Schema;
const defSchemaAttr = require('../common/plugins/defaultSchemaAttr');
const db = require('../connections/dbMaster');
const bcrypt = require('bcrypt-nodejs');
const request = require('request');
const customRequest = request.defaults({
    timeout: 30000
});
const config = require('../config/config');
const studentsConfig = require('../config/studentsConfig');
const countrylookup = require('country-data').lookup;
mongoose.Promise = require('bluebird');

let DailyPresenceSchema = new mongoose.Schema({
    className:{type:String,enum:Object.keys(studentsConfig.classNames),required:true},
    sectionName:{type:String,required:true},
    presentStudents:[{type:mongoose.Schema.Types.ObjectId,ref:"Student"}]
})

// Define our present model
let PresentSchema = new mongoose.Schema({
    date:{type:String,required:true},
    presence:[DailyPresenceSchema]
},{
    minimize: false,
    toJSON: {  
        virtuals: true
    }
});



// Export the Mongoose model
module.exports = db.model('Present', PresentSchema);





