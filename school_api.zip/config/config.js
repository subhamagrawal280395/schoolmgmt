module.exports = {
    db: {
        master: process.env.NODE_ENV === 'test' ? "mongodb://localhost:27017/schoolTest" : "mongodb://localhost:27017/schoolMaster",
        options:{  auto_reconnect: true ,reconnectTries: Number.MAX_SAFE_INTEGER}
    },
    security: {
        tokenLife: 36000
    },
    blockHttp:false,
    appSecret: process.env.APP_SECRET,
}
