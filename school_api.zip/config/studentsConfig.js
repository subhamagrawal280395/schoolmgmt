module.exports = {
    classNames:{
        "first":"first",
        "second":"second",
        "third":"third"
    },
    sectionsInfo:{
        first:["A","B"],
        second:["A"],
        third:["A","B","C"]
    },
    examNames:{
        "1":1,
        "2":2,
        "3":3
    }
}
