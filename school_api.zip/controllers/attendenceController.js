const jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
const config = require('../config/config'); // get our config file
const studentsConfig = require('../config/studentsConfig'); // get our config file
const {
    handleRequest
} = require('../common/utils/utilities')

const {
   get,
   update
} = require('../dbServices/attendence');




exports.add = async (req, res, next) => {
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await update(req.body) });
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}
exports.get = async (req, res, next) => {
    try {
        let [attendence]=await get(req.query.date,req.query.className,req.query.sectionName);
        handleRequest({ 
            res: res, 
            statusCode: 200, 
            msg:"success", 
            result: 1,
            data: attendence
        });
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}