const jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
const config = require('../config/config'); // get our config file
const studentsConfig = require('../config/studentsConfig'); // get our config file
const {
    handleRequest
} = require('../common/utils/utilities')

const {
    create:createStudent,
    getStudentsBySection,
    delete:deleteStudent,
    update:updateStudent,
    addMarks,
    deleteMarks,
    updateMarks,
    getMarks,
    isExamGiven
} = require('../dbServices/student');


exports.getSettings = (req,res) => handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:studentsConfig });


exports.create = async (req, res, next) => {
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await createStudent(req.body) });
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.get = async (req, res, next) => {
    if(!req.query.className || !req.query.sectionName){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await getStudentsBySection(req.query )});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.deleteStudent = async (req, res, next) => {
    if(!req.params.id){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await deleteStudent(req.params.id)});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.updateStudent = async (req, res, next) => {
    if(!req.params.id){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await updateStudent(req.params.id,req.body)});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.addMarks = async (req, res, next) => {
    if(!req.params.id || !req.body.examName || !req.body.subject){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    if(!+req.body.total || !+req.body.gained){
        return handleRequest({ res: res, statusCode: 400, err: 'gained marks and total required', result: 0 });
    }
    if(+req.body.total < +req.body.gained){
        return handleRequest({ res: res, statusCode: 400, err: 'gained marks can not exceed total', result: 0 });
    }
    try {
        if(await isExamGiven(req.params.id,req.body.examName,req.body.subject)) {
            return  handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await updateMarks(req.params.id,req.body)});
        }
        return handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await addMarks(req.params.id,req.body) });
       
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.updateMarks = async (req, res, next) => {
    if(!req.params.id || !req.body.examName || !req.body.subject){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    if(!+req.body.total || !+req.body.gained){
        return handleRequest({ res: res, statusCode: 400, err: 'gained marks and total required', result: 0 });
    }
    if(+req.body.total < +req.body.gained){
        return handleRequest({ res: res, statusCode: 400, err: 'gained marks can not exceed total', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await updateMarks(req.params.id,req.body)});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.getMarks = async (req, res, next) => {
    if(!req.params.id){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await getMarks(req.params.id)});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}

exports.deleteMarks = async (req, res, next) => {
    if(!req.params.id || !req.params.examName  || !req.params.subject){
        return handleRequest({ res: res, statusCode: 400, err: 'Invalid params. please provide all query params to proceed', result: 0 });
    }
    try {
        handleRequest({ res: res, statusCode: 200, msg:"success", result: 1,data:await deleteMarks(req.params.id,req.params.examName,req.params.subject)});
    }
    catch (err) {
        return handleRequest({ res: res, statusCode: 500, err: err, result: 0 });
    }
}


