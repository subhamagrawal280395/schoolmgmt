const {handleRequest}= require('../common/utils/utilities')
const {version} =require('../config/config')
exports.getVersionConfig = (req,res) => handleRequest({res,statusCode:200,result:1,msg:"success",data:version});