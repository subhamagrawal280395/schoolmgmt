var express = require('express');
var router = express.Router();
const students = require('./students');
const attendence = require('./attendence');
const versions = require('./versions');



    // Auth check for all routes
  //router.use(authCheckMiddleWare.isAuthenticated);

  /* GET home page. */
  router.get('/', function(req, res, next) {
    res.render('index', { title: 'Express' });
  });
  router.use('/versions', versions);
  router.use('/students', students);
  router.use('/attendence', attendence);

  module.exports = router;
