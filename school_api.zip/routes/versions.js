var express = require('express');
var router = express.Router();
const  versionController= require('../controllers/versionController');




    router.get('/version' ,versionController.getVersionConfig);


    module.exports = router;

