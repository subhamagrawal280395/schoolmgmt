var express = require('express');
var router = express.Router();
const config = require('../config/config'); // get our config file
const attendenceController = require('../controllers/attendenceController');




    router.post('/' ,attendenceController.add);

    router.get('/' ,attendenceController.get);



    module.exports = router;

