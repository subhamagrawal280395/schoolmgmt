var express = require('express');
var router = express.Router();
const config = require('../config/config'); // get our config file
const studentController = require('../controllers/studentController');


    router.get('/settings' ,studentController.getSettings);


    router.post('/' ,studentController.create);

    router.get('/' ,studentController.get);

    router.put('/:id' ,studentController.updateStudent);

    router.delete('/:id' ,studentController.deleteStudent);



    router.post('/:id/marks' ,studentController.addMarks);

    router.get('/:id/marks' ,studentController.getMarks);

    router.put('/:id/marks' ,studentController.updateMarks);

    router.delete('/:id/marks/:examName/:subject' ,studentController.deleteMarks);

    module.exports = router;

